<h1><?php echo e($otp); ?></h1>
<p>Please enter the OTP in the App to complete registration</p><?php /**PATH C:\xampp\htdocs\watr\resources\views/email/otp.blade.php ENDPATH**/ ?>