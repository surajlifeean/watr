<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('admin.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('stylesheets'); ?>
  
  </head>
  <body id="page-top">
     <div id="wrapper">

        <?php echo $__env->make('admin.partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">

          <div id="content-wrapper" class="d-flex flex-column">
              <!-- Main Content -->
              <div id="content">
                   <?php echo $__env->make('admin.partials._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div><?php echo $__env->make('partials._message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                   
                   <?php echo $__env->yieldContent('content'); ?>
              </div>
          </div>

     </div>

  <?php echo $__env->make('admin.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\watr\resources\views/admin/adminmain.blade.php ENDPATH**/ ?>