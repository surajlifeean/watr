<?php if(Session::has('success')): ?>
	<div class="alert alert-success" role="alert" style="
    margin-bottom: 0px;">
	<strong>Success:</strong><?php echo e(Session::get('success')); ?>

	</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
	<div class="alert alert-danger" role="alert" style="
    margin-bottom: 0px;">
	<?php echo e(Session::get('error')); ?>

	</div>
<?php endif; ?>

<script type="text/javascript">
	
 setTimeout(function() {
        $('.alert').remove();
    }, 8000);
</script><?php /**PATH C:\xampp\htdocs\watr\resources\views/partials/_message.blade.php ENDPATH**/ ?>