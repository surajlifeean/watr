<h1>{{$otp}}</h1>
<p>Please enter the OTP in the App to complete registration</p>